"""Scenario modules for load pattern analysis."""

from geoloadst.scenarios.industrial_daynight import apply_industrial_daynight_pattern

__all__ = ["apply_industrial_daynight_pattern"]

